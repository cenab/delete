# Running docs locally:

`mkdocs build`

`mkdocs serve`

# Deploying docs to GitHub

`mkdocs gh-deploy`

# To address in Sprint 1 docs:

# Project Overview 7/15

- ~~Executive summary does not give a very clear or concrete overview of what the project actually is. Some suggestions:~~
  - ~~In one or two sentences: What is itwêwina?~~
  - ~~What are the current issues with the system?~~
  - ~~What is your team going to change to improve this and add more value to the system?~~
  - ~~“Clean the website to make it more user friendly” is vague~~
    - ~~Clean how? Re-visualizing the paradigm layout panes, ...~~
  - ~~What does “clean the supporting website structures” mean?~~
- ~~You should provide your own glossary, not just link to their repo. All of their terms aren’t necessarily relevant to your specific project~~
- ~~No open source projects listed~~
  - ~~You can be creative here, they don’t just have to be open source projects similar to your project. Anything you can reference or pull some sort of inspiration from will work, as long as you justify your choice. You could even ask the clients if there were any projects that inspired itwêwina initially.~~
- Technical resources listed and analysed

# User Stories 10/20

- ~~The User Stories will need to be reworked now, as we are proceeding with a new MVP front-end. Here’s some feedback based on how they are now though~~
  - The formats are good (As …, I want …, so that …)
  - ~~The numbering doesn’t make sense to start from 5. For the initial project and planning stages, just start from 1~~
  - ~~Need more details in general - they are too vague~~
    - ~~“As a developer I want to be able code be independent so that, So I can better extract it.”~~
    - ~~“As a developer I want to be able I want to use this in my current repo so that, everything is tidy and clean.”~~
      - ~~Use what in my current repo?~~
      - ~~What do you mean by tidy and clean? That’s not a concrete definition to use for acceptance of the story~
  - ~~The Acceptance criteria need more details as well~~
    - ~~“When the user can see stylings”~~
      - ~~How does this apply to US 7.02, 7.03?~~
      - ~~What sylings? Be more specific and concrete~~
    - ~~“When current repo runs without fail”~~
      - ~~What does this mean? As an outside developer, I have no idea~~
    - ~~“Will work without the current repo”~~
      - ~~Same as above~~
  - ~~You need more than 7 User Stories. This is a sign that some stories that are Epics, and too large. Break them down into more concrete and manageable goals.~~
- Planning and developing User Stories is a very important piece of software development, and they are vital for communicating between yourselves, other developers, and your clients what you are actually working towards and accomplishing.

# High-Level Design 10/15

- ~~Architecture diagram is very generic~~
  - ~~Doesn’t really help to describe how the current implementation is working, or how your refactored version will be implemented~~
  - ~~How does the user search for a word?~~
    - ~~There are no requests going from the front-end to the back-end~~
  - ~~The Django app should be accepting and handling the requests from the client, making a call to the paradigm creation application, then passing that context to the templates~~
  - ~~Materialize is a front-end framework~~
    - ~~Is the current system actually using this, or was this just taken from the example diagram?~~
  - ~~When creating your new diagram, be more specific with details like these~~
- UML diagram looks good, explained well in demo
- ~~No descriptions associated with any of the diagrams. They can be briefe, but it would be helpful to describe some of the higher-level interactions of the application that you might not be working on directly~~
  - ~~For example, your explanation of the high-level architecture diagram, and the flow between the different components of the app during the demo provided a lot more clarity to this diagram. I think adding descriptions like this would be very helpful in this project, since it’s already established and so large~~
- Technologies listed in requirements

# Low-Fidelity User Interface 15/15

- Overall, these are well done
- Wireframes show concepts of future functionality
- Navigation paths between screens are shown

# Release Planning 9/15

- ~~Story map represents all four sprints, but the tasks are too large and generic~~
  - ~~They need to be broken down into manageable and concrete tasks. Having more appropriate user stories will help here~~
- ~~Project plan shows major milestones, assignes, and dates - good~~
- ~~There are no github issues - WIP~~
  - ~~There should be issues assigned and labelled corresponding to each task on the storyboard. This needs to be done for each sprint~~
- Team canvas is good

# Teamwork 8/10

- ~~Meeting minutes~~
  - ~~Action item for only one person for only one meeting?~~
  - ~~There should be action items for everyone, after each meeting. Even if they are the same for some members, just say that: continue to work on…~~
- Team and client are now getting on the same page
- Scrum roles are defined and being followed

# Formatting 3/5

- ~~Images aren’t displaying on the gh-paged deployment~~
  - ~~Another team had the same issue - it might be due to the urls in the md files. Try using the full raw url instead, e.g.~~
  - ~~https://raw.githubusercontent.com/UAlberta-CMPUT401/paradigm-layouts/main/docs/images/UML.png?token=~~
- ~~Some typos and errors in the documentation~~

# Mark Breakdown

7 + 10 + 10 + 15 + 9 + 8 + 3 + 5 = 67/100
