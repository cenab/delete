/*
 * The decision flow of cells in rows in panes in paradigm be like
 *                    no            no            no
 * should_be_supress ---> is_label ---> is_empty ---> inflection
 *
 */

const fake_data = {
  nipaw_wordform: {
    should_hide_prose: true,
    displaying_paradigm: true,
    lemma_id: 1140,
    wordform: {
      id: 1140,
      text: "nipâw",
      raw_analysis: null,
      fst_lemma: null,
      paradigm: "personal-pronouns",
      is_lemma: true,
      lemma: 1140,
      slug: "niya",
      linguist_info: {
        inflectional_category: "PrA",
        pos: "Pron",
        wordclass: "PrA",
      },
      import_hash: "d7452fb709105cb623c6",
      definitions: [
        {
          text: "s/he sleeps, s/he is asleep",
          source_ids: ["CW"],
          is_auto_translation: false,
        },
        {
          text: "He sleeps.",
          source_ids: ["CW"],
          is_auto_translation: false,
        },
      ],
      lemma_url: "/word/niya/",
      inflectional_category_plain_english: "like: awa",
      inflectional_category_linguistic: "Pronoun: Animate",
      wordclass_emoji: null,
      inflectional_category: "PrA",
      pos: "Pron",
      wordclass: "PrA",
    },
    paradigm: {
      panes: [
        {
          tr_rows: [
            {
              // row 1
              is_header: true,
              label: "something is happening now",
              cells: [],
            },
            {
              // row 2
              is_header: false,
              label: "",
              cells: [
                {
                  // missing
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: true,
                },
                {
                  // label
                  should_suppress_output: false,
                  is_label: true,
                  label_for: "col",
                  row_span: "",
                  label: "ni-/ki- word",
                },
                {
                  // label
                  should_suppress_output: false,
                  is_label: true,
                  label_for: "col",
                  row_span: "",
                  label: "ê-/kâ- word",
                },
              ],
            },
            {
              // row 3
              is_header: false,
              label: "",
              cells: [
                {
                  // label
                  should_suppress_output: false,
                  is_label: true,
                  label_for: "col",
                  row_span: "",
                  label: "I",
                },
                {
                  // inflection
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: false,
                  is_empty: false,
                  observed: true,
                  inflection: "ninipân",
                },
                {
                  // inflection
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: false,
                  is_empty: false,
                  observed: true,
                  inflection: "	ê-nipâyân",
                },
              ],
            },
            {
              // row 4
              is_header: false,
              label: "",
              cells: [
                {
                  // label
                  should_suppress_output: false,
                  is_label: true,
                  label_for: "col",
                  row_span: "",
                  label: "you (one)",
                },
                {
                  // inflection
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: false,
                  is_empty: false,
                  observed: false,
                  inflection: "kinipân",
                },
                {
                  // inflection
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: false,
                  is_empty: false,
                  observed: true,
                  inflection: "ê-nipâyan",
                },
              ],
            },
            {
              // row 5
              is_header: false,
              label: "",
              cells: [
                {
                  // label
                  should_suppress_output: false,
                  is_label: true,
                  label_for: "col",
                  row_span: "",
                  label: "s/he",
                },
                {
                  // inflection
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: false,
                  is_empty: false,
                  observed: false,
                  inflection: "nipâw",
                },
                {
                  // inflection
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: false,
                  is_empty: false,
                  observed: false,
                  inflection: "ê-nipât",
                },
              ],
            },
            {
              // row 6
              is_header: false,
              label: "",
              cells: [
                {
                  // label
                  should_suppress_output: false,
                  is_label: true,
                  label_for: "col",
                  row_span: "",
                  label: "we (but not you)",
                },
                {
                  // inflection
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: false,
                  is_empty: false,
                  observed: true,
                  inflection: "ninipânân",
                },
                {
                  // inflection
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: false,
                  is_empty: false,
                  observed: false,
                  inflection: "	ê-nipâyân",
                },
              ],
            },
            {
              // row 7
              is_header: false,
              label: "",
              cells: [
                {
                  // label
                  should_suppress_output: false,
                  is_label: true,
                  label_for: "col",
                  row_span: "",
                  label: "you and we",
                },
                {
                  // inflection
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: false,
                  is_empty: false,
                  observed: false,
                  inflection: "	kinipânaw",
                },
                {
                  // inflection
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: false,
                  is_empty: false,
                  observed: true,
                  inflection: "ê-nipâyahk",
                },
              ],
            },
            {
              // row 8
              is_header: false,
              label: "",
              cells: [
                {
                  // missing
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: true,
                },
                {
                  // inflection
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: false,
                  is_empty: false,
                  observed: false,
                  inflection: "	kinipânaw",
                },
                {
                  // missing
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: true,
                },
              ],
            },
            {
              // row 9
              is_header: false,
              label: "",
              cells: [
                {
                  // label
                  should_suppress_output: false,
                  is_label: true,
                  label_for: "col",
                  row_span: "",
                  label: "you (all)",
                },
                {
                  // inflection
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: false,
                  is_empty: false,
                  observed: false,
                  inflection: "	kinipânâwâw",
                },
                {
                  // inflection
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: false,
                  is_empty: false,
                  observed: false,
                  inflection: "ê-nipâyêk",
                },
              ],
            },
          ],
        },
        {
          tr_rows: [
            {
              // row 1
              is_header: true,
              label: "something happened earlier",
              cells: [],
            },
            {
              // row 2
              is_header: false,
              label: "",
              cells: [
                {
                  // missing
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: true,
                },
                {
                  // label
                  should_suppress_output: false,
                  is_label: true,
                  label_for: "col",
                  row_span: "",
                  label: "ni-/ki- word",
                },
                {
                  // label
                  should_suppress_output: false,
                  is_label: true,
                  label_for: "col",
                  row_span: "",
                  label: "ê-/kâ- word",
                },
              ],
            },
            {
              // row 3
              is_header: false,
              label: "",
              cells: [
                {
                  // label
                  should_suppress_output: false,
                  is_label: true,
                  label_for: "col",
                  row_span: "",
                  label: "I",
                },
                {
                  // inflection
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: false,
                  is_empty: false,
                  observed: true,
                  inflection: "ninipân",
                },
                {
                  // inflection
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: false,
                  is_empty: false,
                  observed: true,
                  inflection: "	ê-nipâyân",
                },
              ],
            },
            {
              // row 4
              is_header: false,
              label: "",
              cells: [
                {
                  // label
                  should_suppress_output: false,
                  is_label: true,
                  label_for: "col",
                  row_span: "",
                  label: "you (one)",
                },
                {
                  // inflection
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: false,
                  is_empty: false,
                  observed: false,
                  inflection: "kinipân",
                },
                {
                  // inflection
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: false,
                  is_empty: false,
                  observed: true,
                  inflection: "ê-nipâyan",
                },
              ],
            },
            {
              // row 5
              is_header: false,
              label: "",
              cells: [
                {
                  // label
                  should_suppress_output: false,
                  is_label: true,
                  label_for: "col",
                  row_span: "",
                  label: "s/he",
                },
                {
                  // inflection
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: false,
                  is_empty: false,
                  observed: false,
                  inflection: "nipâw",
                },
                {
                  // inflection
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: false,
                  is_empty: false,
                  observed: false,
                  inflection: "ê-nipât",
                },
              ],
            },
            {
              // row 6
              is_header: false,
              label: "",
              cells: [
                {
                  // label
                  should_suppress_output: false,
                  is_label: true,
                  label_for: "col",
                  row_span: "",
                  label: "we (but not you)",
                },
                {
                  // inflection
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: false,
                  is_empty: false,
                  observed: true,
                  inflection: "ninipânân",
                },
                {
                  // inflection
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: false,
                  is_empty: false,
                  observed: false,
                  inflection: "	ê-nipâyân",
                },
              ],
            },
            {
              // row 7
              is_header: false,
              label: "",
              cells: [
                {
                  // label
                  should_suppress_output: false,
                  is_label: true,
                  label_for: "col",
                  row_span: "",
                  label: "you and we",
                },
                {
                  // inflection
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: false,
                  is_empty: false,
                  observed: false,
                  inflection: "	kinipânaw",
                },
                {
                  // inflection
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: false,
                  is_empty: false,
                  observed: true,
                  inflection: "ê-nipâyahk",
                },
              ],
            },
            {
              // row 8
              is_header: false,
              label: "",
              cells: [
                {
                  // missing
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: true,
                },
                {
                  // inflection
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: false,
                  is_empty: false,
                  observed: false,
                  inflection: "	kinipânaw",
                },
                {
                  // missing
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: true,
                },
              ],
            },
            {
              // row 9
              is_header: false,
              label: "",
              cells: [
                {
                  // label
                  should_suppress_output: false,
                  is_label: true,
                  label_for: "col",
                  row_span: "",
                  label: "you (all)",
                },
                {
                  // inflection
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: false,
                  is_empty: false,
                  observed: false,
                  inflection: "	kinipânâwâw",
                },
                {
                  // inflection
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: false,
                  is_empty: false,
                  observed: false,
                  inflection: "ê-nipâyêk",
                },
              ],
            },
          ],
        },
        {
          tr_rows: [
            {
              // row 1
              is_header: true,
              label: "something is going to happen",
              cells: [],
            },
            {
              // row 2
              is_header: false,
              label: "",
              cells: [
                {
                  // missing
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: true,
                },
                {
                  // label
                  should_suppress_output: false,
                  is_label: true,
                  label_for: "col",
                  row_span: "",
                  label: "ni-/ki- word",
                },
                {
                  // label
                  should_suppress_output: false,
                  is_label: true,
                  label_for: "col",
                  row_span: "",
                  label: "ê-/kâ- word",
                },
              ],
            },
            {
              // row 3
              is_header: false,
              label: "",
              cells: [
                {
                  // label
                  should_suppress_output: false,
                  is_label: true,
                  label_for: "col",
                  row_span: "",
                  label: "I",
                },
                {
                  // inflection
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: false,
                  is_empty: false,
                  observed: true,
                  inflection: "ninipân",
                },
                {
                  // inflection
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: false,
                  is_empty: false,
                  observed: true,
                  inflection: "	ê-nipâyân",
                },
              ],
            },
            {
              // row 4
              is_header: false,
              label: "",
              cells: [
                {
                  // label
                  should_suppress_output: false,
                  is_label: true,
                  label_for: "col",
                  row_span: "",
                  label: "you (one)",
                },
                {
                  // inflection
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: false,
                  is_empty: false,
                  observed: false,
                  inflection: "kinipân",
                },
                {
                  // inflection
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: false,
                  is_empty: false,
                  observed: true,
                  inflection: "ê-nipâyan",
                },
              ],
            },
            {
              // row 5
              is_header: false,
              label: "",
              cells: [
                {
                  // label
                  should_suppress_output: false,
                  is_label: true,
                  label_for: "col",
                  row_span: "",
                  label: "s/he",
                },
                {
                  // inflection
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: false,
                  is_empty: false,
                  observed: false,
                  inflection: "nipâw",
                },
                {
                  // inflection
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: false,
                  is_empty: false,
                  observed: false,
                  inflection: "ê-nipât",
                },
              ],
            },
            {
              // row 6
              is_header: false,
              label: "",
              cells: [
                {
                  // label
                  should_suppress_output: false,
                  is_label: true,
                  label_for: "col",
                  row_span: "",
                  label: "we (but not you)",
                },
                {
                  // inflection
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: false,
                  is_empty: false,
                  observed: true,
                  inflection: "ninipânân",
                },
                {
                  // inflection
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: false,
                  is_empty: false,
                  observed: false,
                  inflection: "	ê-nipâyân",
                },
              ],
            },
            {
              // row 7
              is_header: false,
              label: "",
              cells: [
                {
                  // label
                  should_suppress_output: false,
                  is_label: true,
                  label_for: "col",
                  row_span: "",
                  label: "you and we",
                },
                {
                  // inflection
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: false,
                  is_empty: false,
                  observed: false,
                  inflection: "	kinipânaw",
                },
                {
                  // inflection
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: false,
                  is_empty: false,
                  observed: true,
                  inflection: "ê-nipâyahk",
                },
              ],
            },
            {
              // row 8
              is_header: false,
              label: "",
              cells: [
                {
                  // missing
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: true,
                },
                {
                  // inflection
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: false,
                  is_empty: false,
                  observed: false,
                  inflection: "	kinipânaw",
                },
                {
                  // missing
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: true,
                },
              ],
            },
            {
              // row 9
              is_header: false,
              label: "",
              cells: [
                {
                  // label
                  should_suppress_output: false,
                  is_label: true,
                  label_for: "col",
                  row_span: "",
                  label: "you (all)",
                },
                {
                  // inflection
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: false,
                  is_empty: false,
                  observed: false,
                  inflection: "	kinipânâwâw",
                },
                {
                  // inflection
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: false,
                  is_empty: false,
                  observed: false,
                  inflection: "ê-nipâyêk",
                },
              ],
            },
          ],
        },
        {
          tr_rows: [
            {
              // row 1
              is_header: true,
              label: "something will certainly happen",
              cells: [],
            },
            {
              // row 2
              is_header: false,
              label: "",
              cells: [
                {
                  // missing
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: true,
                },
                {
                  // label
                  should_suppress_output: false,
                  is_label: true,
                  label_for: "col",
                  row_span: "",
                  label: "ni-/ki- word",
                },
                {
                  // label
                  should_suppress_output: false,
                  is_label: true,
                  label_for: "col",
                  row_span: "",
                  label: "ê-/kâ- word",
                },
              ],
            },
            {
              // row 3
              is_header: false,
              label: "",
              cells: [
                {
                  // label
                  should_suppress_output: false,
                  is_label: true,
                  label_for: "col",
                  row_span: "",
                  label: "I",
                },
                {
                  // inflection
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: false,
                  is_empty: false,
                  observed: true,
                  inflection: "ninipân",
                },
                {
                  // inflection
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: false,
                  is_empty: false,
                  observed: true,
                  inflection: "	ê-nipâyân",
                },
              ],
            },
            {
              // row 4
              is_header: false,
              label: "",
              cells: [
                {
                  // label
                  should_suppress_output: false,
                  is_label: true,
                  label_for: "col",
                  row_span: "",
                  label: "you (one)",
                },
                {
                  // inflection
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: false,
                  is_empty: false,
                  observed: false,
                  inflection: "kinipân",
                },
                {
                  // inflection
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: false,
                  is_empty: false,
                  observed: true,
                  inflection: "ê-nipâyan",
                },
              ],
            },
            {
              // row 5
              is_header: false,
              label: "",
              cells: [
                {
                  // label
                  should_suppress_output: false,
                  is_label: true,
                  label_for: "col",
                  row_span: "",
                  label: "s/he",
                },
                {
                  // inflection
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: false,
                  is_empty: false,
                  observed: false,
                  inflection: "nipâw",
                },
                {
                  // inflection
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: false,
                  is_empty: false,
                  observed: false,
                  inflection: "ê-nipât",
                },
              ],
            },
            {
              // row 6
              is_header: false,
              label: "",
              cells: [
                {
                  // label
                  should_suppress_output: false,
                  is_label: true,
                  label_for: "col",
                  row_span: "",
                  label: "we (but not you)",
                },
                {
                  // inflection
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: false,
                  is_empty: false,
                  observed: true,
                  inflection: "ninipânân",
                },
                {
                  // inflection
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: false,
                  is_empty: false,
                  observed: false,
                  inflection: "	ê-nipâyân",
                },
              ],
            },
            {
              // row 7
              is_header: false,
              label: "",
              cells: [
                {
                  // label
                  should_suppress_output: false,
                  is_label: true,
                  label_for: "col",
                  row_span: "",
                  label: "you and we",
                },
                {
                  // inflection
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: false,
                  is_empty: false,
                  observed: false,
                  inflection: "	kinipânaw",
                },
                {
                  // inflection
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: false,
                  is_empty: false,
                  observed: true,
                  inflection: "ê-nipâyahk",
                },
              ],
            },
            {
              // row 8
              is_header: false,
              label: "",
              cells: [
                {
                  // missing
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: true,
                },
                {
                  // inflection
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: false,
                  is_empty: false,
                  observed: false,
                  inflection: "	kinipânaw",
                },
                {
                  // missing
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: true,
                },
              ],
            },
            {
              // row 9
              is_header: false,
              label: "",
              cells: [
                {
                  // label
                  should_suppress_output: false,
                  is_label: true,
                  label_for: "col",
                  row_span: "",
                  label: "you (all)",
                },
                {
                  // inflection
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: false,
                  is_empty: false,
                  observed: false,
                  inflection: "	kinipânâwâw",
                },
                {
                  // inflection
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: false,
                  is_empty: false,
                  observed: false,
                  inflection: "ê-nipâyêk",
                },
              ],
            },
          ],
        },
        {
          tr_rows: [
            {
              // row 1
              is_header: true,
              label: "for something to happen",
              cells: [],
            },
            {
              // row 2
              is_header: false,
              label: "",
              cells: [
                {
                  // missing
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: true,
                },
                {
                  // label
                  should_suppress_output: false,
                  is_label: true,
                  label_for: "col",
                  row_span: "",
                  label: "ni-/ki- word",
                },
                {
                  // label
                  should_suppress_output: false,
                  is_label: true,
                  label_for: "col",
                  row_span: "",
                  label: "ê-/kâ- word",
                },
              ],
            },
            {
              // row 3
              is_header: false,
              label: "",
              cells: [
                {
                  // label
                  should_suppress_output: false,
                  is_label: true,
                  label_for: "col",
                  row_span: "",
                  label: "I",
                },
                {
                  // inflection
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: false,
                  is_empty: false,
                  observed: true,
                  inflection: "ninipân",
                },
                {
                  // inflection
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: false,
                  is_empty: false,
                  observed: true,
                  inflection: "	ê-nipâyân",
                },
              ],
            },
            {
              // row 4
              is_header: false,
              label: "",
              cells: [
                {
                  // label
                  should_suppress_output: false,
                  is_label: true,
                  label_for: "col",
                  row_span: "",
                  label: "you (one)",
                },
                {
                  // inflection
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: false,
                  is_empty: false,
                  observed: false,
                  inflection: "kinipân",
                },
                {
                  // inflection
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: false,
                  is_empty: false,
                  observed: true,
                  inflection: "ê-nipâyan",
                },
              ],
            },
            {
              // row 5
              is_header: false,
              label: "",
              cells: [
                {
                  // label
                  should_suppress_output: false,
                  is_label: true,
                  label_for: "col",
                  row_span: "",
                  label: "s/he",
                },
                {
                  // inflection
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: false,
                  is_empty: false,
                  observed: false,
                  inflection: "nipâw",
                },
                {
                  // inflection
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: false,
                  is_empty: false,
                  observed: false,
                  inflection: "ê-nipât",
                },
              ],
            },
            {
              // row 6
              is_header: false,
              label: "",
              cells: [
                {
                  // label
                  should_suppress_output: false,
                  is_label: true,
                  label_for: "col",
                  row_span: "",
                  label: "we (but not you)",
                },
                {
                  // inflection
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: false,
                  is_empty: false,
                  observed: true,
                  inflection: "ninipânân",
                },
                {
                  // inflection
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: false,
                  is_empty: false,
                  observed: false,
                  inflection: "	ê-nipâyân",
                },
              ],
            },
            {
              // row 7
              is_header: false,
              label: "",
              cells: [
                {
                  // label
                  should_suppress_output: false,
                  is_label: true,
                  label_for: "col",
                  row_span: "",
                  label: "you and we",
                },
                {
                  // inflection
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: false,
                  is_empty: false,
                  observed: false,
                  inflection: "	kinipânaw",
                },
                {
                  // inflection
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: false,
                  is_empty: false,
                  observed: true,
                  inflection: "ê-nipâyahk",
                },
              ],
            },
            {
              // row 8
              is_header: false,
              label: "",
              cells: [
                {
                  // missing
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: true,
                },
                {
                  // inflection
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: false,
                  is_empty: false,
                  observed: false,
                  inflection: "	kinipânaw",
                },
                {
                  // missing
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: true,
                },
              ],
            },
            {
              // row 9
              is_header: false,
              label: "",
              cells: [
                {
                  // label
                  should_suppress_output: false,
                  is_label: true,
                  label_for: "col",
                  row_span: "",
                  label: "you (all)",
                },
                {
                  // inflection
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: false,
                  is_empty: false,
                  observed: false,
                  inflection: "	kinipânâwâw",
                },
                {
                  // inflection
                  should_suppress_output: false,
                  is_label: false,
                  is_missing: false,
                  is_empty: false,
                  observed: false,
                  inflection: "ê-nipâyêk",
                },
              ],
            },
          ],
        },
      ],
    },
    paradigm_size: "<only-size>",
    paradigm_sizes: ["<only-size>"],
    query_string: "",
    did_search: false,
  },
  niya_recordings: [
    {
      anonymous: false,
      gender: "M",
      language: Array["Maskwacîs"],
      recording_url:
        "http://speech-db.altlab.app/media/audio/126e139b690593ba6a8977f3795b95de85bfb37bfc588e8c6c9fb6b3f7462aa1_jQ6YdQz.m4a",
      speaker: "GOR",
      speaker_bio_url: "https://speech-db.altlab.app/maskwacis/speakers/GOR",
      speaker_name: "kîsikâw",
      wordform: "niya",
    },
    {
      anonymous: false,
      gender: "M",
      language: Array["Maskwacîs"],
      recording_url:
        "http://speech-db.altlab.app/media/audio/e689922cb8575245f436c7ce74e6c00aa4c10c9af79c1053c3b2b2c173bd0dd0_24ARhjH.m4a",
      speaker: "HAR",
      speaker_bio_url: "https://speech-db.altlab.app/maskwacis/speakers/HAR",
      speaker_name: "Harley Simon",
      wordform: "niya",
    },
    {
      anonymous: false,
      gender: "F",
      language: Array["Maskwacîs"],
      recording_url:
        "http://speech-db.altlab.app/media/audio/81d18bd31c3048a38600b76b3bc18f63e9c85772cb57605ad61da1186c00a764_XF2Yb35.m4a",
      speaker: "JEAN",
      speaker_bio_url: "https://speech-db.altlab.app/maskwacis/speakers/JEAN",
      speaker_name: "Mary Jean Littlechild",
      wordform: "niya",
    },
  ],
};

export default fake_data;
