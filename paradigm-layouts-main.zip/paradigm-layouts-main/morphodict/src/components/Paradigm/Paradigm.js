import "../style.css";
import Pane from "./Pane";

function Paradigm(paradigm) {
  const panes = paradigm.paradigm.panes;
  const pane_layouts = panes.map((pane) => <Pane rows={pane.tr_rows}></Pane>);

  return (
    <section
      className="definition__paradigm paradigm js-replaceable-paradigm"
      data-cy="paradigm"
    >
      <table className="paradigm__table">{pane_layouts}</table>
    </section>
  );
}

export default Paradigm;
