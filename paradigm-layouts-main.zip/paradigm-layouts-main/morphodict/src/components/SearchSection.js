/*
Name   : SearchSection
Inputs : Props ()
    
display: The resulting json image from the file. 
index  : the resulting index of the item from the returned array. 
       
Goal   : The purpose of this page is to display the search results gotten from user search. This is a single display of the word before a user picks the current file. 
       
Testing: 
        (1) Done through visual look.
        (2) TODO: Provide cypress tests for given front end information. 
        (3) TODO: Find intergration tests from main front end. 
        (4) TODO: Add success message to copy (Alert maybe check with clinet)
        (5) TODO: Find if clinet want to keep the like thing as it is now. 

API CALLS:

*/

import {Tooltip, OverlayTrigger, Button} from "react-bootstrap"
import LikeWord from "./LikeWord";

const SearchSection = (props) =>{
    
    const wordInformation = props.display;
    //const wordIndex = props.index;
    const wordsDefs = wordInformation["definitions"];
    // -> MD(?) CW(?) CW+MD(?) --> needs to change for part of sprint 3

    let information = wordInformation["friendly_linguistic_breakdown_tail"];
    let inflectionCatagory = wordInformation["lemma_wordform"]["inflectional_category_linguistic"] + " (" + wordInformation["lemma_wordform"]["inflectional_category"] + ")"; // This is passed into LikeWord

    let infoBtn = "";
    let soundBtn = "";
    let sound = "a"; // Done as a test until api info is filled in sp2
    let wordBtn = "";


    if (information != ""){
        infoBtn = <Button variant="btn bg-white rounded shadow-none" onClick={() => navigator.clipboard.writeText(wordInformation["lemma_wordform"]["linguist_info"]["stem"] + " - " + information)} size="lg"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-info-circle" viewBox="0 0 16 16">
        <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
        <path d="m8.93 6.588-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533L8.93 6.588zM9 4.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"/>
      </svg></Button>
    }
    
    //Information BTN tooltip(Here is where the info is to be typed out)
    const renderInformationToolTip = (props) => (
        <Tooltip id="button-tooltip" {...props}>
            {wordInformation["lemma_wordform"]["linguist_info"]["stem"]}
            <br />
            {information}
        </Tooltip>
      );

    //Information on api only learned on 2/24/2022 moved into sp3
    if (sound != ""){
        soundBtn = <Button variant="btn bg-white rounded" size="lg"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-soundwave" viewBox="0 0 16 16">
        <path fillRule="evenodd" d="M8.5 2a.5.5 0 0 1 .5.5v11a.5.5 0 0 1-1 0v-11a.5.5 0 0 1 .5-.5zm-2 2a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-1 0v-7a.5.5 0 0 1 .5-.5zm4 0a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-1 0v-7a.5.5 0 0 1 .5-.5zm-6 1.5A.5.5 0 0 1 5 6v4a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm8 0a.5.5 0 0 1 .5.5v4a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm-10 1A.5.5 0 0 1 3 7v2a.5.5 0 0 1-1 0V7a.5.5 0 0 1 .5-.5zm12 0a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0V7a.5.5 0 0 1 .5-.5z"/>
      </svg></Button>
    }

    // Todo: Add link/route to paradigm of word Sprint 3 (SP#3)
    wordBtn = <Button variant="btn bg-white rounded shadow-none" >
        <a className="link-primary text-center h3">    
            {/*When font-settings is built in sp3 make the check from the local store here */}
            {wordInformation["lemma_wordform"]["text"]}
        </a>
    </Button>     

    return(
        
        <div id="results" className="shadow p-3 mb-5 bg-body rounded">
            <div className="d-flex flex-row">

                <div className="p-1">
                    {wordBtn}
                </div>

                <div className="p-1">
                    <OverlayTrigger
                    placement="bottom"
                    delay={{ show: 250, hide: 400 }}
                    overlay={renderInformationToolTip}>
                        {infoBtn}
                    </OverlayTrigger>

                </div>

                <div className="p-2">
                    {soundBtn}
                </div>
                
            </div>
            {/* change the following to actual word info*/}
            <LikeWord likeWord={wordInformation["lemma_wordform"]["inflectional_category_linguistic"]} emoticon={wordInformation["lemma_wordform"]["wordclass_emoji"]} hoverInfo={inflectionCatagory}/>
            
            <></>

            <ul class="list-group text-center">
                {
                    wordsDefs.map((item, i) =>(
                        <li class="list-group-item ">
                            {i+1}. {item["text"]} : {item["source_ids"]}
                            {/*TODO: make a better trigger for src so that they can copy the tooltip SP3*/}
                        </li>       
                    ))
                }
            </ul>
        </div>
    )
}

export default SearchSection;