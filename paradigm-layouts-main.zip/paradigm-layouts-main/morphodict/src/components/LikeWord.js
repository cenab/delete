/*
Name   : LikeWord
Inputs : Props ()
       
    likeWord        : a similer word to the current word found.   
    emoticon        : the emoticon that will show the current word 
    wordInformation : class of the word(current) information
       
Goal         : Show word information and also provide the ability to highlight and copy that information to the users clipboard. 
       
Testing: 
        (1) Done through visual look.
        (2) TODO: Provide cypress tests for given front end information. 
        (3) TODO: Find intergration tests from main front end. 
        (4) TODO: Add success message to copy (Alert maybe check with clinet)
        (5) TODO: Find if clinet want to keep the like thing as it is now. 
*/

import {Tooltip, OverlayTrigger, Button} from "react-bootstrap"

const LikeWord = (props) =>{
    const likeWord = props.likeWord;
    const emoticon = props.emoticon;
    const wordInformation = props.hoverInfo;
    
    //Don't exactly understand the whole emoticon thing.
    //Will need to ask cline to explain that information
    //to me. :(
    const infoLink = <Button 
        variant="btn bg-white rounded shadow-none text-decoration-underline" 
        onClick={() => navigator.clipboard.writeText(wordInformation)}>
            {emoticon}  — {likeWord}
        </Button>
    
    const renderInformationToolTip = (props) => (
        <Tooltip id="word-info-tooltip" {...props}>
            {wordInformation}
            </Tooltip>
    );

    return(
        <div className="container">

            <div className="d-flex flex-row">
                <div className="mb-auto p-2">
                    <OverlayTrigger
                    placement="bottom"
                    delay={{ show: 250, hide: 400 }}
                    overlay={renderInformationToolTip}>
                    {infoLink}
                    </OverlayTrigger>
                </div>
            </div>
        </div>
    )

}

export default LikeWord