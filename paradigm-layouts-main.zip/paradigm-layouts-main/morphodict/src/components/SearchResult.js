/*
Name          : SearchSection
Inputs        : Props () 
              
  queryString : The current search word typed by the user.    
               
Goal          : Display a list of words that best match the queryString. 
              
Testing       : 
                (1) Done through visual look.
                (2) TODO: Provide cypress tests for given front end information. 
                (3) TODO: Find intergration tests from main front end. 


Known Issues:
      State is not saved. Need to save state otherwise we risk a timeout making an error. 
*/

import SearchSection from "./SearchSection"
import 'bootstrap/dist/css/bootstrap.min.css';
import {Alert} from "react-bootstrap"

import newFakeWord from '../Fake_words/new_fake_word_search.json'

function SearchResult(props) {
  //const queryString = props.location.state.queryString;

  //(CALL: POST: -->localhost:8000/api/search/ -H 'Content-Type: application/json' -d '{"name":"atâhk"}'<--) wordSeard is the json result of this call. Current fake because of deployment problems with client db.
 
  let wordSearch = newFakeWord;
  const results = wordSearch["search_results"];

  return (  

    <div className="container">
      {/* What happens if we get no results from search intergration on sp3*/}
      {
        results.length == 0 && 
        <>
        <Alert variant="danger">
          <Alert.Heading>Pîkiskâci: No results found for &lt;&lt; TEST NONE &gt;&gt;</Alert.Heading>
        </Alert>
        </>
      }


      <div className="container">
        {/* what happens if we get a result from the the db call*/}
        {
          results.map((result, word_index) =>(
            <SearchSection display={result} index={word_index}></SearchSection>
          ))
        }
      </div>

    </div>
  );
}
export default SearchResult;
