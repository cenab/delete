/*
Name   : CreeDictionarySettings
Inputs : Props () None Allowed
       
Goal   : Allows the user to chaneg the settings of the app
       
Testing: 
        (1) Done through visual look.
        (2) TODO: Provide cypress tests for given front end information. 
        (3) TODO: Find intergration tests from main front end. 
        (4) TODO: Add success message to copy (Alert maybe check with clinet)
        (5) TODO: Find if clinet want to keep the like thing as it is now. 

TODO: Find out how global state needs to be changed. Needs to be done in sprint 3(SP3)
*/

import { ListGroup, Form } from "react-bootstrap";
import "react-bootstrap"

function CreeDictionarySettings(props) {
  return (
    <div className="container bg-white">
      <h1>Settings</h1>
      
      <h2>Paradigm labels</h2>
      <p className="font-weight-light">
        These are the labels that appear on the <b>paradigm table</b> to label features like person, tense, plurals, etc.
      </p>

      <ListGroup variant="flush">
        <ListGroup.Item>   
          <Form.Check 
            type={'checkbox'}
            id={'plain-engl'}
            label="Plain English labels"
          />
          <p className="font-weight-light">Examples: I, you (one), s/he; something is happening now, something happened earlier</p>
          </ListGroup.Item>

          <ListGroup.Item>   
            <Form.Check 
              type={'checkbox'}
              id={'ling-lab'}
              label="Linguistic labels"
            /> 
          <p className="font-weight-light">Examples: 1s, 2s, 3s; Present, Past</p>
        
        </ListGroup.Item>
          <ListGroup.Item>   
            <Form.Check 
              type={'checkbox'}
              id={'niya-label'}
              label="Nêhiyawêwin labels"
            />
          <p className="font-weight-light">Examples: niya, kiya, wiya; ê-ispayik anohc/mêkwâc/mâna, ê-ispayik kwayâc</p>
        </ListGroup.Item>
      </ListGroup>

      <h2>Emoji for animate nouns (awa words)</h2>
      <p className="font-weight-light">Choose the emoji that will represent all awa words.</p>

      <ListGroup variant="flush">
        <ListGroup.Item>
          <Form.Check 
                type={'checkbox'}
                id={'man-emoti'}
                label="🧑🏽"
              />
        </ListGroup.Item>
        <ListGroup.Item>
          <Form.Check 
                type={'checkbox'}
                id={'gamma-emoti'}
                label="👵🏽"
          />
        </ListGroup.Item>
        <ListGroup.Item>
        <Form.Check 
                type={'checkbox'}
                id={'gapa-emoti'}
                label="👴🏽"
              />
        </ListGroup.Item>
        
        <ListGroup.Item>
        <Form.Check 
                type={'checkbox'}
                id={'wolf-emoti'}
                label="🐺"
              />
        </ListGroup.Item>
        <ListGroup.Item>
        <Form.Check 
                type={'checkbox'}
                id={'bear-emoti'}
                label="🐻"
              />
        </ListGroup.Item>
        <ListGroup.Item>
        <Form.Check 
                type={'checkbox'}
                id={'bred-emoti'}
                label="🍞"
              />
        </ListGroup.Item>
        <ListGroup.Item>
        <Form.Check 
                type={'checkbox'}
                id={'star-emoti'}
                label="🌟"
              />
        </ListGroup.Item>
      </ListGroup>

      <h2>Select Dictionary Source</h2>
      <p className="font-weight-light">Select one of the following options to chose which entries are displayed in the search results</p>
      
      <ListGroup variant="flush">
        <ListGroup.Item>
        <Form.Check 
                type={'checkbox'}
                id={'CW-DIC'}
                label="CW"
              />
              <p>Show entries from the Cree: Words dictionary. Wolvengrey, Arok, editor. Cree: Words. Regina, University of Regina Press, 2001</p>
        </ListGroup.Item>
        <ListGroup.Item>
        <Form.Check 
                type={'checkbox'}
                id={'MD-DIC'}
                label="MD"
              />
              <p>Show entries from the Maskwacîs Dictionary. Maskwacîs Dictionary. Maskwacîs, Maskwachees Cultural College, 1998.</p>
        </ListGroup.Item>
        <ListGroup.Item>
        <Form.Check 
                type={'checkbox'}
                id={'ALL-DIC'}
                label="CW-MD"
              />
              Show entries from CW and MD (default)
        </ListGroup.Item>
      </ListGroup>

    </div>
  );
}

export default CreeDictionarySettings;
