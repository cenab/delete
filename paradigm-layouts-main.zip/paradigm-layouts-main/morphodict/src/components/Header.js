import "./style.css";
import morphodict_default_logo from "../static/morphodict-default-logo-192.png";

import React, { useState } from "react";
import { TextField } from "@mui/material";
import { Redirect } from "react-router-dom";

function Header(props) {
  const [dictionaryName, setDictionaryName] = useState("itwêwina");
  const [sourceLanguageName, setSourceLanguageName] = useState("Plains Cree");
  const [queryString, setQueryString] = useState("");
  const [query, setQuery] = useState(false);
  const [settingMenu, setSettingMenu] = useState({
    Latn: "SRO (êîôâ)",
    "Latn-x-macron": "SRO (ēīōā)",
    Cans: "Syllabics",
  });

  const handleSettingChange = (value) => {
    // TODO: NEED API
    // need setting api
    console.log(value);
  };

  const handleSearchKey = (e) => {
    if (e.key == "Enter") {
      // TODO: NEED API
      // need searching api
      console.log("Enter pressed");
      setQuery(true);
    }
  };

  const handleSearchText = ({ target }) => {
    setQueryString(target.value);
  };

  return (
    <div className="top-bar app__header">
      {query ? (
        <Redirect
          to={{
            pathname: "/search-result",
            state: {
              queryString: queryString,
              query: query,
            },
          }}
        ></Redirect>
      ) : null}
      <header className="branding top-bar__logo">
        <a className="branding__logo" href="/">
          <img
            className="branding__image"
            src={morphodict_default_logo}
            alt="mîkiwâhp (teepee) logo"
          ></img>

          <hgroup className="branding__text">
            <h1 className="branding__heading branding__title">
              {" "}
              {dictionaryName}
            </h1>
            <p
              className="branding__heading branding__subtitle"
              role="doc-subtitle"
            >
              {sourceLanguageName} Dictionary
            </p>
          </hgroup>
        </a>
      </header>
      <nav className="search top-bar__search">
        <TextField
          id="search"
          variant="outlined"
          fullWidth
          label="Search"
          onKeyUp={handleSearchKey}
          onChange={handleSearchText}
        ></TextField>
      </nav>
      <nav className="top-bar__nav">
        <details className="toggle-box toggle-box--with-menu close-on-click-away">
          <summary
            id="settings-menu__button"
            className="toggle-box__toggle"
            data-cy="settings-menu"
            aria-haspopup="menu"
            tabIndex="0"
          >
            Settings
          </summary>

          <div
            className="menu toggle-box__menu"
            aria-labelledby="settings-menu__button"
          >
            <div className="menu__category">
              <h3 className="menu__header">
                Show {sourceLanguageName} words in…
              </h3>
              <ul className="menu__choices" data-cy="orthography-choices">
                {/* list of setting menu */}
                {Object.keys(settingMenu).map((id) => (
                  <li className="menu-choice">
                    <button
                      data-orth-switch
                      value={id}
                      className="unbutton fill-width"
                      onClick={() => handleSettingChange(id)}
                    >
                      <span className="menu-choice__label">
                        {settingMenu[id]}
                      </span>
                    </button>
                  </li>
                ))}
              </ul>
            </div>

            <hr className="menu__separator"></hr>

            <div className="menu__category">
              <a
                href="/cree-dictionary-settings"
                className="menu-choice"
                data-cy="settings-link"
              >
                <span className="menu-choice__label fill-width">
                  View all settings
                </span>
              </a>
            </div>
          </div>
        </details>
      </nav>
    </div>
  );
}

export default Header;
