import "./App.css";
import "./components/style.css";

import Layout from "./components/Layout";
import { Route } from "react-router-dom";
import WordEntry from "./components/WordEntry";
import About from "./components/About";
import ContactUs from "./components/ContactUs";
import Welcome from "./components/Welcome";
import CreeDictionarySettings from "./components/CreeDictionarySettings";
import SearchResult from "./components/SearchResult";
import AbbreviationsLegend from "./components/AbbreviationsLegend";

function App() {
  return (
    <Layout>
      <Route exact path="/">
        <Welcome></Welcome>
      </Route>

      <Route exact path="/about">
        <About></About>
      </Route>

      <Route exact path="/contact-us">
        <ContactUs></ContactUs>
      </Route>

      <Route exact path="/cree-dictionary-settings">
        <CreeDictionarySettings></CreeDictionarySettings>
      </Route>

      <Route exact path="/word/*">
        <WordEntry></WordEntry>
      </Route>

      <Route
        exact
        path="/search-result"
        render={(props) => <SearchResult {...props}></SearchResult>}
      ></Route>

      <Route exact path="/cree-dictionary-legend">
        <AbbreviationsLegend></AbbreviationsLegend>
      </Route>
    </Layout>
  );
}

export default App;
