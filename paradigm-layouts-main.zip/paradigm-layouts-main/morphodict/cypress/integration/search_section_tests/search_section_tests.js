// selection_cmp_right_item_count.js created with Cypress
// The edmonton CW thing is an issue with the test data not with the site itself. 

describe('Checks if sections shows consonants', () => {
    it('shows only the two fake data points', () => {
      cy.visit("http://localhost:3000/search-result")
      cy.contains("Consonant-/w/ animate noun stem")
    })
  })

  describe('Checks if sections shows the right two orderings ', () => {
    it('shows only the two fake data points', () => {
      cy.visit("http://localhost:3000/search-result")
      cy.contains("1. Edmonton, AB : CW")
      cy.contains("2. Fort Edmonton : CW")
      cy.contains("1. beaver : CW")
    })
  })
