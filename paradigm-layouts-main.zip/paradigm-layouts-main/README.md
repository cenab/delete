# paradigm-layouts
itwêwina paradigm layouts (ALT Lab)